package dominio.excepcion;

public class UsuarioExistente extends Exception {

}


package dominio.locker;

public enum TipoLocker {

    PEQUENIO,MEDIANO,GRANDE
}
